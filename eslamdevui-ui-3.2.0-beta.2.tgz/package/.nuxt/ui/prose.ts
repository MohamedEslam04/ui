export default {
  "a": {
    "base": [
      "text-primary border-b border-transparent hover:border-primary font-medium focus-visible:outline-primary [&>code]:border-dashed hover:[&>code]:border-primary hover:[&>code]:text-primary",
      "transition-colors [&>code]:transition-colors"
    ]
  },
  "accordion": {
    "slots": {
      "root": "my-5",
      "trigger": "text-base"
    }
  },
  "accordionItem": {
    "base": "pb-4 text-muted *:first:mt-0 *:last:mb-0 *:my-1.5"
  },
  "badge": {
    "base": "rounded-full"
  },
  "blockquote": {
    "base": "border-s-4 border-accented ps-4 italic"
  },
  "cardGroup": {
    "base": "grid grid-cols-1 sm:grid-cols-2 gap-5 my-5 *:my-0"
  },
  "codeCollapse": {
    "slots": {
      "root": "relative [&_pre]:h-[200px]",
      "footer": "h-16 absolute inset-x-px bottom-px rounded-b-md flex items-center justify-center",
      "trigger": "group",
      "triggerIcon": "group-data-[state=open]:rotate-180"
    },
    "variants": {
      "open": {
        "true": {
          "root": "[&_pre]:h-auto [&_pre]:min-h-[200px] [&_pre]:max-h-[80vh] [&_pre]:pb-12"
        },
        "false": {
          "root": "[&_pre]:overflow-hidden",
          "footer": "bg-gradient-to-t from-muted"
        }
      }
    }
  },
  "codeGroup": {
    "slots": {
      "root": "relative group *:not-first:!my-0 *:not-first:!static my-5",
      "list": "relative flex items-center gap-1 border border-muted bg-default border-b-0 rounded-t-md overflow-x-auto p-2",
      "indicator": "absolute left-0 inset-y-2 w-(--reka-tabs-indicator-size) translate-x-(--reka-tabs-indicator-position) transition-[translate,width] duration-200 bg-elevated rounded-md shadow-xs",
      "trigger": [
        "relative inline-flex items-center gap-1.5 text-default data-[state=active]:text-highlighted hover:bg-elevated/50 px-2 py-1.5 text-sm rounded-md disabled:cursor-not-allowed disabled:opacity-75 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary focus:outline-none",
        "transition-colors"
      ],
      "triggerIcon": "size-4 shrink-0",
      "triggerLabel": "truncate"
    }
  },
  "codeIcon": {
    "package.json": "i-vscode-icons-file-type-node",
    "tsconfig.json": "i-vscode-icons-file-type-tsconfig",
    ".npmrc": "i-vscode-icons-file-type-npm",
    ".editorconfig": "i-vscode-icons-file-type-editorconfig",
    ".eslintrc": "i-vscode-icons-file-type-eslint",
    ".eslintrc.cjs": "i-vscode-icons-file-type-eslint",
    ".eslintignore": "i-vscode-icons-file-type-eslint",
    "eslint.config.js": "i-vscode-icons-file-type-eslint",
    "eslint.config.mjs": "i-vscode-icons-file-type-eslint",
    "eslint.config.cjs": "i-vscode-icons-file-type-eslint",
    ".gitignore": "i-vscode-icons-file-type-git",
    "yarn.lock": "i-vscode-icons-file-type-yarn",
    ".env": "i-vscode-icons-file-type-dotenv",
    ".env.example": "i-vscode-icons-file-type-dotenv",
    ".vscode/settings.json": "i-vscode-icons-file-type-vscode",
    "nuxt": "i-vscode-icons-file-type-nuxt",
    ".nuxtrc": "i-vscode-icons-file-type-nuxt",
    ".nuxtignore": "i-vscode-icons-file-type-nuxt",
    "nuxt.config.js": "i-vscode-icons-file-type-nuxt",
    "nuxt.config.ts": "i-vscode-icons-file-type-nuxt",
    "nuxt.schema.ts": "i-vscode-icons-file-type-nuxt",
    "tailwind.config.js": "i-vscode-icons-file-type-tailwind",
    "tailwind.config.ts": "i-vscode-icons-file-type-tailwind",
    "vue": "i-vscode-icons-file-type-vue",
    "ts": "i-vscode-icons-file-type-typescript",
    "tsx": "i-vscode-icons-file-type-typescript",
    "mjs": "i-vscode-icons-file-type-js",
    "cjs": "i-vscode-icons-file-type-js",
    "js": "i-vscode-icons-file-type-js",
    "jsx": "i-vscode-icons-file-type-js",
    "md": "i-vscode-icons-file-type-markdown",
    "py": "i-vscode-icons-file-type-python",
    "cs": "i-vscode-icons-file-type-csharp",
    "asm": "i-vscode-icons-file-type-assembly",
    "f": "i-vscode-icons-file-type-fortran",
    "hs": "i-vscode-icons-file-type-haskell",
    "fs": "i-vscode-icons-file-type-fsharp",
    "kt": "i-vscode-icons-file-type-kotlin",
    "rs": "i-vscode-icons-file-type-rust",
    "rb": "i-vscode-icons-file-type-ruby",
    "lsp": "i-vscode-icons-file-type-lisp",
    "ps1": "i-vscode-icons-file-type-powershell",
    "psd1": "i-vscode-icons-file-type-powershell",
    "psm1": "i-vscode-icons-file-type-powershell",
    "go": "i-vscode-icons-file-type-go",
    "gleam": "i-vscode-icons-file-type-gleam",
    "bicep": "i-vscode-icons-file-type-bicep",
    "bicepparam": "i-vscode-icons-file-type-bicep",
    "exs": "i-vscode-icons-file-type-elixir",
    "erl": "i-vscode-icons-file-type-erlang",
    "sbt": "i-vscode-icons-file-type-scala",
    "h": "i-vscode-icons-file-type-cppheader",
    "ino": "i-vscode-icons-file-type-arduino",
    "pl": "i-vscode-icons-file-type-perl",
    "jl": "i-vscode-icons-file-type-julia",
    "dart": "i-vscode-icons-file-type-dartlang",
    "ico": "i-vscode-icons-file-type-favicon",
    "npm": "i-vscode-icons-file-type-npm",
    "pnpm": "i-vscode-icons-file-type-pnpm",
    "npx": "i-vscode-icons-file-type-npm",
    "yarn": "i-vscode-icons-file-type-yarn",
    "bun": "i-vscode-icons-file-type-bun",
    "yml": "i-vscode-icons-file-type-yaml",
    "terminal": "i-lucide-terminal"
  },
  "codePreview": {
    "slots": {
      "root": "my-5",
      "preview": "flex justify-center border border-muted relative p-4 rounded-md",
      "code": "[&>div>pre]:rounded-t-none [&>div]:my-0"
    },
    "variants": {
      "code": {
        "true": {
          "preview": "border-b-0 rounded-b-none"
        }
      }
    }
  },
  "codeTree": {
    "slots": {
      "root": "relative lg:h-[450px] my-5 grid lg:grid-cols-3 border border-muted rounded-md",
      "list": "isolate relative p-2 border-b lg:border-b-0 lg:border-e border-muted overflow-y-auto",
      "item": "",
      "listWithChildren": "ms-4.5 border-s border-default",
      "itemWithChildren": "ps-1.5 -ms-px",
      "link": "relative group peer w-full px-2.5 py-1.5 before:inset-y-px before:inset-x-0 flex items-center gap-1.5 text-sm before:absolute before:z-[-1] before:rounded-md focus:outline-none focus-visible:outline-none focus-visible:before:ring-inset focus-visible:before:ring-2",
      "linkLeadingIcon": "size-4 shrink-0",
      "linkLabel": "truncate",
      "linkTrailing": "ms-auto inline-flex gap-1.5 items-center",
      "linkTrailingIcon": "size-5 transform transition-transform duration-200 shrink-0 group-data-expanded:rotate-180",
      "content": "overflow-hidden lg:col-span-2 flex flex-col [&>div]:my-0 [&>div]:flex-1 [&>div]:flex [&>div]:flex-col [&>div>div]:border-0 [&>div>pre]:border-b-0 [&>div>pre]:border-s-0 [&>div>pre]:border-e-0 [&>div>pre]:rounded-l-none [&>div>pre]:flex-1 [&>div]:overflow-y-auto"
    },
    "variants": {
      "active": {
        "true": {
          "link": "text-highlighted before:bg-elevated"
        },
        "false": {
          "link": [
            "hover:text-highlighted hover:before:bg-elevated/50",
            "transition-colors before:transition-colors"
          ]
        }
      }
    }
  },
  "collapsible": {
    "slots": {
      "root": "my-5",
      "trigger": [
        "group relative rounded-xs inline-flex items-center gap-1.5 text-muted hover:text-default text-sm focus-visible:ring-2 focus-visible:ring-primary focus:outline-none",
        "transition-colors"
      ],
      "triggerIcon": "size-4 shrink-0 group-data-[state=open]:rotate-180 transition-transform duration-200",
      "triggerLabel": "truncate",
      "content": "*:first:mt-2.5 *:last:mb-0 *:my-1.5"
    }
  },
  "em": {
    "base": ""
  },
  "field": {
    "slots": {
      "root": "my-5",
      "container": "flex items-center gap-3 font-mono text-sm",
      "name": "font-semibold text-primary",
      "wrapper": "flex-1 flex items-center gap-1.5 text-xs",
      "required": "rounded-sm bg-error/10 text-error px-1.5 py-0.5",
      "type": "rounded-sm bg-elevated text-toned px-1.5 py-0.5",
      "description": "mt-3 text-muted text-sm [&_code]:text-xs/4"
    }
  },
  "fieldGroup": {
    "base": "my-5 divide-y divide-default *:not-last:pb-5"
  },
  "h1": {
    "slots": {
      "base": "text-4xl text-highlighted font-bold mb-8 scroll-mt-[calc(45px+var(--ui-header-height))] lg:scroll-mt-(--ui-header-height)",
      "link": "inline-flex items-center gap-2"
    }
  },
  "h2": {
    "slots": {
      "base": [
        "relative text-2xl text-highlighted font-bold mt-12 mb-6 scroll-mt-[calc(48px+45px+var(--ui-header-height))] lg:scroll-mt-[calc(48px+var(--ui-header-height))] [&>a]:focus-visible:outline-primary [&>a>code]:border-dashed hover:[&>a>code]:border-primary hover:[&>a>code]:text-primary [&>a>code]:text-xl/7 [&>a>code]:font-bold",
        "[&>a>code]:transition-colors"
      ],
      "leading": [
        "absolute -ms-8 top-1 opacity-0 group-hover:opacity-100 group-focus:opacity-100 p-1 bg-elevated hover:text-primary rounded-md hidden lg:flex text-muted",
        "transition"
      ],
      "leadingIcon": "size-4 shrink-0",
      "link": "group lg:ps-2 lg:-ms-2"
    }
  },
  "h3": {
    "slots": {
      "base": [
        "relative text-xl text-highlighted font-bold mt-8 mb-3 scroll-mt-[calc(32px+45px+var(--ui-header-height))] lg:scroll-mt-[calc(32px+var(--ui-header-height))] [&>a]:focus-visible:outline-primary [&>a>code]:border-dashed hover:[&>a>code]:border-primary hover:[&>a>code]:text-primary [&>a>code]:text-lg/6 [&>a>code]:font-bold",
        "[&>a>code]:transition-colors"
      ],
      "leading": [
        "absolute -ms-8 top-0.5 opacity-0 group-hover:opacity-100 group-focus:opacity-100 p-1 bg-elevated hover:text-primary rounded-md hidden lg:flex text-muted",
        "transition"
      ],
      "leadingIcon": "size-4 shrink-0",
      "link": "group lg:ps-2 lg:-ms-2"
    }
  },
  "h4": {
    "slots": {
      "base": "text-lg text-highlighted font-bold mt-6 mb-2 scroll-mt-[calc(24px+45px+var(--ui-header-height))] lg:scroll-mt-[calc(24px+var(--ui-header-height))] [&>a]:focus-visible:outline-primary",
      "link": ""
    }
  },
  "hr": {
    "base": "border-t border-default my-12"
  },
  "icon": {
    "base": "size-4 shrink-0 align-sub"
  },
  "img": {
    "base": ""
  },
  "kbd": {
    "base": "align-text-top"
  },
  "li": {
    "base": "my-1.5 ps-1.5 leading-7 [&>ul]:my-0"
  },
  "ol": {
    "base": "list-decimal ps-6 my-5 marker:text-muted"
  },
  "p": {
    "base": "my-5 leading-7 text-pretty"
  },
  "pre": {
    "slots": {
      "root": "relative my-5 group",
      "header": "flex items-center gap-1.5 border border-muted bg-default border-b-0 relative rounded-t-md px-4 py-3",
      "filename": "text-default text-sm/6",
      "icon": "size-4 shrink-0",
      "copy": "absolute top-[11px] right-[11px] lg:opacity-0 lg:group-hover:opacity-100 transition",
      "base": "group font-mono text-sm/6 border border-muted bg-muted rounded-md px-4 py-3 whitespace-pre-wrap break-words overflow-x-auto focus:outline-none"
    },
    "variants": {
      "filename": {
        "true": {
          "root": "[&>pre]:rounded-t-none [&>pre]:my-0 my-5"
        }
      }
    }
  },
  "steps": {
    "base": "ms-4 border-s border-default ps-8 [counter-reset:step]",
    "variants": {
      "level": {
        "2": "[&>h2]:[counter-increment:step] [&>h2]:relative [&>h2]:before:absolute [&>h2]:before:size-8 [&>h2]:before:bg-elevated [&>h2]:before:rounded-full [&>h2]:before:font-semibold [&>h2]:before:text-sm [&>h2]:before:tabular-nums [&>h2]:before:inline-flex [&>h2]:before:items-center [&>h2]:before:justify-center [&>h2]:before:ring-4 [&>h2]:before:ring-bg [&>h2]:before:-ms-[48.5px] [&>h2]:before:-mt-0 [&>h2]:before:content-[counter(step)] [&>h2>a>span.absolute]:hidden",
        "3": "[&>h3]:[counter-increment:step] [&>h3]:relative [&>h3]:before:absolute [&>h3]:before:size-7 [&>h3]:before:inset-x-0.5 [&>h3]:before:bg-elevated [&>h3]:before:rounded-full [&>h3]:before:font-semibold [&>h3]:before:text-sm [&>h3]:before:tabular-nums [&>h3]:before:inline-flex [&>h3]:before:items-center [&>h3]:before:justify-center [&>h3]:before:ring-4 [&>h3]:before:ring-bg [&>h3]:before:-ms-[48.5px] [&>h3]:before:content-[counter(step)] [&>h3>a>span.absolute]:hidden",
        "4": "[&>h4]:[counter-increment:step] [&>h4]:relative [&>h4]:before:absolute [&>h4]:before:size-7 [&>h4]:before:inset-x-0.5 [&>h4]:before:bg-elevated [&>h4]:before:rounded-full [&>h4]:before:font-semibold [&>h4]:before:text-sm [&>h4]:before:tabular-nums [&>h4]:before:inline-flex [&>h4]:before:items-center [&>h4]:before:justify-center [&>h4]:before:ring-4 [&>h4]:before:ring-bg [&>h4]:before:-ms-[48.5px] [&>h4]:before:content-[counter(step)] [&>h4>a>span.absolute]:hidden"
      }
    },
    "defaultVariants": {
      "level": "3"
    }
  },
  "strong": {
    "base": ""
  },
  "table": {
    "slots": {
      "root": "relative my-5 overflow-x-auto",
      "base": "w-full border-separate border-spacing-0 rounded-md"
    }
  },
  "tabs": {
    "slots": {
      "root": "my-5 gap-4"
    }
  },
  "tabsItem": {
    "base": "*:first:mt-0 *:last:mb-0 *:my-1.5"
  },
  "tbody": {
    "base": ""
  },
  "td": {
    "base": "py-3 px-4 text-sm text-left align-top border-e border-b first:border-s border-muted [&_code]:text-xs/5 [&_p]:my-0 [&_p]:leading-6 [&_ul]:my-0 [&_ol]:my-0 [&_ul]:ps-4.5 [&_ol]:ps-4.5 [&_li]:leading-6 [&_li]:my-0.5"
  },
  "th": {
    "base": "py-3 px-4 font-semibold text-sm text-left border-e border-b first:border-s border-t border-muted"
  },
  "thead": {
    "base": "bg-muted"
  },
  "tr": {
    "base": "[&:first-child>th:first-child]:rounded-tl-md [&:first-child>th:last-child]:rounded-tr-md [&:last-child>td:first-child]:rounded-bl-md [&:last-child>td:last-child]:rounded-br-md"
  },
  "ul": {
    "base": "list-disc ps-6 my-5 marker:text-(--ui-border-accented)"
  }
}